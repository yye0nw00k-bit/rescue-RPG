단어 사전은 app.py의 KOREAN_BANK / ENGLISH_BANK에 기본 데이터로 들어 있습니다.
더 많은 단어는 app.py의 해당 딕셔너리에 추가하면 됩니다. 품사는 noun(명사), verb(동사), adjective(형용사)를 사용합니다.
훈민정음은 별도 사전에 의존하지 않고 입력한 단어의 초성을 검사합니다.
