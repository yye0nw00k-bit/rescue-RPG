(() => {
  if (typeof io === 'undefined') {
    const list = document.getElementById('room-list');
    if (list) list.innerHTML = '<div class="empty-state"><strong>실시간 연결 스크립트를 불러오지 못했어.</strong><span>인터넷 연결을 확인하고 새로고침해 줘.</span></div>';
    return;
  }
  const socket = io();
  const $ = id => document.getElementById(id);
  let allRooms = [];
  let roomFilter = 'all';
  let activeRoomId = null;
  let latestState = null;
  let toastTimer = null;

  const modeNames = {ko:'한국어 끝말잇기', en:'영어 끝말잇기', hunmin:'훈민정음'};
  const partNames = {all:'전체', noun:'명사만', verb:'동사만', adjective:'형용사만'};
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function showToast(message) {
    const el = $('toast'); if (!el) return;
    el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
  }
  function setFeedback(message, good=false) {
    const el = $('word-feedback'); if (!el) return;
    el.textContent = message || ''; el.classList.toggle('good', !!good);
  }
  function renderRooms() {
    const list = $('room-list'); if (!list) return;
    const filtered = allRooms.filter(r => roomFilter === 'all' || r.kind === roomFilter);
    $('room-count').textContent = filtered.length;
    if (!filtered.length) {
      list.innerHTML = `<div class="empty-state"><div class="empty-icon">⌁</div><strong>${roomFilter === 'all' ? '아직 열린 방이 없어' : '이 모드에 열린 방이 없어'}</strong><span>첫 번째 방을 만들고 친구들을 불러 봐.</span><button class="btn primary small" data-open-create="1">＋ 방 만들기</button></div>`;
      return;
    }
    list.innerHTML = filtered.map(r => {
      const typeClass = r.kind === 'en' ? 'en' : (r.kind === 'hunmin' ? 'hunmin' : '');
      const setting = r.kind === 'hunmin' ? `초성 ${esc(r.chosung)}` : `${esc(partNames[r.part] || '전체')} · 두음 ${r.dueum ? '허용' : '미허용'}`;
      const disabled = r.started || r.players >= r.max_players;
      const btnText = r.started ? '진행 중' : (r.players >= r.max_players ? '방 가득 참' : '참가하기 →');
      return `<article class="room-card"><div class="room-card-top"><span class="mode-badge ${typeClass}">${esc(modeNames[r.kind] || '끝말잇기')}</span><span class="room-players">♙ ${r.players}/${r.max_players}</span></div><h3>${esc(r.name)}</h3><div class="room-card-meta"><span>${esc(setting)}</span></div><div class="room-card-bottom"><span class="host-name">방장 · ${esc(r.host)}</span><button class="join-btn" data-join="${esc(r.id)}" ${disabled ? 'disabled' : ''}>${btnText}</button></div></article>`;
    }).join('');
  }
  function renderPlayers(state) {
    const list = $('player-list');
    const alive = state.players || [];
    $('player-count').textContent = `${alive.length}/8`;
    $('waiting-note').classList.toggle('hidden', !!state.started);
    list.innerHTML = alive.map(p => {
      const current = state.current_user_id === p.id && state.started && !p.is_out;
      return `<div class="player-item ${current ? 'current-turn' : ''} ${p.is_out ? 'eliminated' : ''}"><span class="player-avatar">${esc((p.nickname || '?').slice(0,1))}</span><div class="player-details"><strong>${esc(p.nickname)} ${p.is_host ? '<span class="host-tag">방장</span>' : ''}</strong><small>${p.is_out ? '기권함' : (current ? '지금 입력할 차례' : '참가 중')}</small></div><span class="player-score">${p.points || 0}P</span></div>`;
    }).join('');
    if (!alive.length) list.innerHTML = '<div class="history-empty">참가자가 없어.</div>';
  }
  function renderHistory(state) {
    const history = state.history || [];
    $('history-count').textContent = history.length;
    if (!history.length) {
      $('word-history').innerHTML = '<div class="history-empty">아직 나온 단어가 없어.</div>';
      return;
    }
    $('word-history').innerHTML = history.slice().reverse().map((item, i) => `<div class="history-item"><span class="history-index">${String(history.length-i).padStart(2,'0')}</span><span class="history-word">${esc(item.word)}</span><span class="history-player">${esc(item.nickname)}</span><span class="history-time">${esc(item.at || '')}</span></div>`).join('');
  }
  function applyRoomState(state) {
    latestState = state; activeRoomId = state.id;
    $('lobby-section').classList.add('hidden');
    $('game-panel').classList.remove('hidden');
    $('game-room-name').textContent = state.name;
    $('game-mode').textContent = modeNames[state.kind] || '끝말잇기';
    $('game-room-desc').textContent = `${state.players.length}명 참가 · 방장 ${state.players.find(p => p.is_host)?.nickname || '—'}`;
    $('rule-part').textContent = partNames[state.part] || '전체';
    $('rule-dueum').textContent = state.dueum ? '허용' : '미허용';
    $('rule-chosung').textContent = state.chosung || '—';
    $('rule-chosung').parentElement.classList.toggle('hidden', state.kind !== 'hunmin');
    $('last-word').innerHTML = state.last_word ? esc(state.last_word) : (state.kind === 'hunmin' ? `${esc(state.chosung)} <span class="cursor-blink">▍</span>` : '시작 단어를 기다리는 중 <span class="cursor-blink">▍</span>');
    renderPlayers(state); renderHistory(state);
    const isHost = state.host_id === MY_ID;
    $('start-game').classList.toggle('hidden', !isHost || state.started || state.finished);
    $('start-game').disabled = state.players.length < 2;
    $('start-game').textContent = state.players.length < 2 ? '참가자 기다리는 중' : '게임 시작 →';
    const isMyTurn = state.current_user_id === MY_ID;
    const canPlay = state.started && !state.finished && isMyTurn;
    $('word-input').disabled = !canPlay;
    $('word-submit').disabled = !canPlay;
    $('word-input').placeholder = state.kind === 'hunmin' ? `${state.chosung} 초성에 맞는 단어` : (canPlay ? '단어를 입력해 줘' : '네 차례가 되면 입력할 수 있어');
    $('surrender').classList.toggle('hidden', !state.started || state.finished || !state.players.some(p => p.id === MY_ID && !p.is_out));
    const status = $('game-status');
    status.textContent = state.finished ? '게임 종료' : (state.started ? '게임 진행 중' : '대기 중');
    status.classList.toggle('playing', state.started && !state.finished);
    if (state.finished) {
      $('turn-hint').textContent = state.winner ? `${state.winner} 승리! 이번 판이 끝났어.` : (state.message || '이번 판이 끝났어.');
      $('start-game').classList.add('hidden');
      $('word-input').disabled = true; $('word-submit').disabled = true;
      $('surrender').classList.add('hidden');
      showToast(state.message || '게임이 끝났어.');
    } else if (!state.started) {
      $('turn-hint').textContent = state.players.length < 2 ? '참가자가 2명 모이면 시작할 수 있어.' : (isHost ? '준비가 되면 게임 시작을 눌러 줘.' : '방장이 게임을 시작할 때까지 기다려 줘.');
    } else if (isMyTurn) {
      $('turn-hint').textContent = state.last_word ? '네 차례야! 마지막 글자에 맞춰 이어 줘.' : '네 차례야! 첫 단어를 입력해 줘.';
    } else {
      const player = state.players.find(p => p.id === state.current_user_id);
      $('turn-hint').textContent = `${player ? player.nickname : '다른 참가자'} 님이 입력 중이야.`;
    }
  }

  socket.on('connect', () => socket.emit('get_rooms'));
  socket.on('rooms_update', rooms => { allRooms = Array.isArray(rooms) ? rooms : []; renderRooms(); });
  socket.on('joined_room', data => { activeRoomId = data.room_id; setFeedback(''); $('word-input').value = ''; });
  socket.on('room_state', state => applyRoomState(state));
  socket.on('word_result', result => setFeedback(result.message, result.ok));
  socket.on('notice', data => showToast((data && data.message) || '요청을 처리하지 못했어.'));
  socket.on('connect_error', () => showToast('서버에 연결할 수 없어. 잠시 뒤 다시 시도해 줘.'));

  const dialog = $('create-dialog');
  $('open-create').addEventListener('click', () => dialog.showModal());
  $('close-create').addEventListener('click', () => dialog.close());
  $('cancel-create').addEventListener('click', () => dialog.close());
  $('create-kind').addEventListener('change', () => {
    const hunmin = $('create-kind').value === 'hunmin';
    $('chosung-wrap').classList.toggle('hidden', !hunmin);
    $('part-wrap').classList.toggle('hidden', hunmin);
    $('dueum-wrap').classList.toggle('hidden', hunmin || $('create-kind').value === 'en');
  });
  $('create-form').addEventListener('submit', e => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    socket.emit('create_room', {name:form.get('name'),kind:form.get('kind'),part:form.get('part'),dueum:form.has('dueum'),chosung:form.get('chosung')});
    dialog.close();
  });
  $('refresh-rooms').addEventListener('click', () => { socket.emit('get_rooms'); showToast('방 목록을 새로고침했어.'); });
  document.querySelectorAll('.filter').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach(b => b.classList.toggle('active', b === btn));
    roomFilter = btn.dataset.filter; renderRooms();
  }));
  $('room-list').addEventListener('click', e => {
    const create = e.target.closest('[data-open-create]');
    if (create) { dialog.showModal(); return; }
    const join = e.target.closest('[data-join]');
    if (join && !join.disabled) { socket.emit('join_room', {room_id:join.dataset.join}); }
  });
  $('start-game').addEventListener('click', () => { if (activeRoomId) socket.emit('start_game', {room_id:activeRoomId}); });
  $('word-form').addEventListener('submit', e => {
    e.preventDefault();
    const word = $('word-input').value.trim(); if (!word || !activeRoomId) return;
    socket.emit('submit_word', {room_id:activeRoomId,word}); $('word-input').value = '';
  });
  $('surrender').addEventListener('click', () => {
    if (activeRoomId && confirm('이번 판을 기권할까?')) socket.emit('surrender', {room_id:activeRoomId});
  });
  $('leave-room').addEventListener('click', () => {
    if (activeRoomId) socket.emit('leave_room', {room_id:activeRoomId});
    activeRoomId = null; latestState = null;
    $('game-panel').classList.add('hidden'); $('lobby-section').classList.remove('hidden');
    socket.emit('get_rooms');
  });
})();
