# 라스트 투게더 (Last Together)

한국어·영어 끝말잇기와 훈민정음 초성 게임을 즐기는 Flask + Socket.IO 웹 게임입니다. 방 만들기, 품사 제한, 두음법칙 설정, 회원가입/로그인, 점수 랭킹, 관리자 밴/밴 해제/점수 변경 기능을 포함합니다.

## Windows에서 실행하기

1. Python 3.11 이상을 설치합니다.
2. 이 폴더에서 PowerShell을 엽니다.
3. 아래 명령어를 차례대로 실행합니다.

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
py app.py
```

브라우저에서 `http://127.0.0.1:5000`을 엽니다. 관리자 닉네임은 `최연욱`이며 로그인 아이디 칸에 `최연욱` 또는 `admin`을 입력할 수 있습니다. 기본 관리자 비밀번호는 사용자가 정한 값으로 설정되어 있습니다. 공개 배포에서는 Render의 `ADMIN_PASSWORD` 환경 변수에 이 비밀번호를 설정하세요.

## Render에 배포하기

이 프로젝트에는 Render Blueprint 설정 파일 `render.yaml`이 포함되어 있습니다.

1. GitHub에 새 저장소를 만들고 이 폴더 안의 파일을 올립니다. `app.py`, `requirements.txt`, `render.yaml`, `templates/`, `static/`이 저장소 최상위에 있어야 합니다.
2. Render에서 **New + → Blueprint**를 선택하고 GitHub 저장소를 연결합니다. 일반 Web Service를 직접 만들 경우에는 Runtime `Python`, Build Command `pip install -r requirements.txt`, Start Command `gunicorn --worker-class gthread --threads 100 --bind 0.0.0.0:$PORT app:app`를 사용합니다.
3. 플랜으로 **Free**를 고릅니다. 서비스 이름은 `last-together`로 설정되어 있습니다. 주소가 이미 사용 중이면 Render가 다른 주소를 요구하거나 표시할 수 있습니다.
4. `ADMIN_PASSWORD`를 요청받으면 관리자 비밀번호를 입력합니다. `ADMIN_NICKNAME`은 `최연욱`으로 둡니다. `SECRET_KEY`는 Render 설정에서 자동 생성됩니다.
5. 배포가 끝나면 서비스 URL을 엽니다.

## 저장 데이터에 관한 중요 안내

기본 설정은 SQLite를 사용합니다. Render 무료 웹 서비스의 로컬 파일은 영구 저장되지 않으므로, 서비스가 재시작·다시 배포되거나 유휴 상태에서 내려갈 때 계정과 점수가 초기화될 수 있습니다. 계속 보존하려면 `DATABASE_URL`에 PostgreSQL 연결 주소를 설정해야 합니다. Render의 무료 PostgreSQL은 생성 후 30일에 만료될 수 있으니, 장기 보존이 필요하면 만료 조건을 먼저 확인하세요.

실시간 방은 현재 실행 중인 프로세스의 메모리에 저장되므로, 서비스가 재시작되면 진행 중인 방은 사라집니다. 무료 웹 서비스는 일정 시간 요청이 없으면 잠들 수 있고, 다음 접속 시 다시 시작하는 데 시간이 걸릴 수 있습니다.

## 기능

- 회원가입, 로그인, 비밀번호 해시 저장
- 한국어 및 영어 끝말잇기 방
- 훈민정음 초성 방 (예: `ㅅㄴㄲ` → `사냥꾼`)
- 방 이름, 품사 제한, 두음법칙, 초성 설정
- Socket.IO 실시간 방 목록·참가자·단어 기록 업데이트
- 단어 입력 점수와 랭킹
- 관리자 센터: 밴, 밴 해제, 점수 조정
- 모바일 화면 대응

## 사전 안내

시작 사전은 테스트용 기본 단어 목록입니다. 끄투 전체 사전이 포함된 것은 아니며, 더 많은 단어를 사용하려면 `app.py`의 `KOREAN_BANK`와 `ENGLISH_BANK`를 확장해야 합니다.
