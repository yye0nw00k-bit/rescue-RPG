import os
import re
import time
import uuid
import random
import threading
from datetime import datetime
from collections import Counter

from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'replace-this-secret-before-deploying')
database_url = os.getenv('DATABASE_URL', 'sqlite:///last_together.db')
if database_url.startswith('postgres://'):
    database_url = database_url.replace('postgres://', 'postgresql://', 1)
app.config['SQLALCHEMY_DATABASE_URI'] = database_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'pool_pre_ping': True}
db = SQLAlchemy(app)
socketio = SocketIO(app, async_mode='threading', cors_allowed_origins=None, manage_session=True)

ADMIN_NICKNAME = os.getenv('ADMIN_NICKNAME', '최연욱')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD')
# Fallback hash allows the requested first-run admin password without exposing it in source.
DEFAULT_ADMIN_PASSWORD_HASH = 'pbkdf2:sha256:600000$last-together-admin-salt-91f2c7$28afc12491f774eafd08e150e9dbc1e1131e3e741238d5a51b8abfff9ee35d9c'


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False)
    nickname = db.Column(db.String(24), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_banned = db.Column(db.Boolean, default=False, nullable=False)
    ban_reason = db.Column(db.String(240), default='', nullable=False)
    points = db.Column(db.Integer, default=0, nullable=False)
    wins = db.Column(db.Integer, default=0, nullable=False)
    games = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def public(self):
        return {'id': self.id, 'nickname': self.nickname, 'points': self.points,
                'wins': self.wins, 'games': self.games, 'is_admin': self.is_admin}


# Starter word bank. It is intentionally easy to extend in word_bank.py or add larger files later.
# Entries are tagged by part of speech to make room filters work.
KOREAN_BANK = {
    '사과':'noun','과자':'noun','자동차':'noun','차표':'noun','표범':'noun','범인':'noun','인형':'noun','형제':'noun','제비':'noun','비누':'noun','누나':'noun','나무':'noun','무지개':'noun','개구리':'noun','리본':'noun','본능':'noun','능력':'noun','력사':'noun','사람':'noun','람보':'noun',
    '바다':'noun','다리':'noun','리모컨':'noun','컨텐츠':'noun','츠바키':'noun','키보드':'noun','드라마':'noun','마을':'noun','을지로':'noun','로봇':'noun','봇물':'noun','물고기':'noun','기차':'noun','차량':'noun','양말':'noun','말벌':'noun','벌꿀':'noun','꿀벌':'noun','벌레':'noun','레몬':'noun','몬스터':'noun',
    '토끼':'noun','끼니':'noun','니트':'noun','트럭':'noun','럭비':'noun','비행기':'noun','기린':'noun','린스':'noun','스포츠':'noun','츠바키':'noun','수박':'noun','박수':'noun','수영':'noun','영화':'noun','화분':'noun','분필':'noun','필통':'noun','통장':'noun','장난감':'noun','감자':'noun',
    '자전거':'noun','거울':'noun','울타리':'noun','리더':'noun','더위':'noun','위성':'noun','성냥':'noun','냥이':'noun','이발':'noun','발자국':'noun','국수':'noun','수도':'noun','도서관':'noun','관광':'noun','광장':'noun','장미':'noun','미술':'noun','술잔':'noun','잔디':'noun','디자인':'noun',
    '인사':'noun','사전':'noun','전구':'noun','구름':'noun','름차':'noun','차례':'noun','례절':'noun','절벽':'noun','벽돌':'noun','돌고래':'noun','래퍼':'noun','퍼즐':'noun','즐거움':'noun','음악':'noun','악기':'noun','기억':'noun','억울함':'noun','함박꽃':'noun','꽃병':'noun','병원':'noun',
    '원숭이':'noun','이야기':'noun','기회':'noun','회사':'noun','사장':'noun','장갑':'noun','갑옷':'noun','옷장':'noun','장마':'noun','마술':'noun','술래':'noun','래미안':'noun','안경':'noun','경찰':'noun','찰흙':'noun','흙탕물':'noun','물감':'noun','감각':'noun','각도':'noun','도깨비':'noun',
    '비둘기':'noun','기숙사':'noun','사탕':'noun','탕수육':'noun','육회':'noun','회사원':'noun','원숭이':'noun','이불':'noun','불꽃':'noun','꽃게':'noun','게임':'noun','임금':'noun','금요일':'noun','일요일':'noun','일기':'noun','기상':'noun','상자':'noun','자물쇠':'noun','쇠고기':'noun','기름':'noun',
    '름통':'noun','통나무':'noun','무대':'noun','대문':'noun','문어':'noun','어부':'noun','부자':'noun','자동문':'noun','문제':'noun','제목':'noun','목소리':'noun','리듬':'noun','듬직함':'noun','함성':'noun','성공':'noun','공책':'noun','책상':'noun','상어':'noun','어항':'noun','항구':'noun',
    '구두':'noun','두부':'noun','부엌':'noun','억새':'noun','새우':'noun','우산':'noun','산책':'noun','책방':'noun','방울':'noun','울음':'noun','음료':'noun','료리':'noun','리어카':'noun','카메라':'noun','라디오':'noun','오리':'noun','리코더':'noun','더덕':'noun','덕담':'noun','담요':'noun',
    '요리':'noun','리그':'noun','그림':'noun','림프':'noun','프린터':'noun','터널':'noun','널뛰기':'noun','기차역':'noun','역사':'noun','사슴':'noun','슴베':'noun','베개':'noun','개미':'noun','미소':'noun','소나무':'noun','무지':'noun','지구':'noun','구조':'noun','조각':'noun','각설탕':'noun',
    '가다':'verb','오다':'verb','먹다':'verb','마시다':'verb','달리다':'verb','읽다':'verb','쓰다':'verb','보다':'verb','듣다':'verb','웃다':'verb','울다':'verb','걷다':'verb','뛰다':'verb','날다':'verb','놀다':'verb','자다':'verb','일하다':'verb','공부하다':'verb','그리다':'verb','만들다':'verb','배우다':'verb','가르치다':'verb','말하다':'verb','생각하다':'verb','사랑하다':'verb','춤추다':'verb','노래하다':'verb','찾다':'verb','열다':'verb','닫다':'verb','기다리다':'verb','쉬다':'verb','앉다':'verb','서다':'verb','잡다':'verb','놓다':'verb','주다':'verb','받다':'verb','키우다':'verb','던지다':'verb','살다':'verb','죽다':'verb','웃기다':'verb','좋다':'adjective','크다':'adjective','작다':'adjective','빠르다':'adjective','느리다':'adjective','예쁘다':'adjective','재미있다':'adjective','어렵다':'adjective','쉽다':'adjective','높다':'adjective','낮다':'adjective','밝다':'adjective','어둡다':'adjective','춥다':'adjective','덥다':'adjective','길다':'adjective','짧다':'adjective','넓다':'adjective','좁다':'adjective','무겁다':'adjective','가볍다':'adjective','맛있다':'adjective','맛없다':'adjective'
}

ENGLISH_BANK = {}
def add_words(words, pos='noun'):
    for word in words.split():
        ENGLISH_BANK[word.lower()] = pos

add_words('apple elephant tiger rabbit table egg garden night tree earth house school lamp phone orange river road dog game eagle engine envelope energy yellow window water rainbow world dream music key yak kangaroo owl lion notebook keyboard dragon grape elephant ant train nose ear ring guitar robot tomato ocean network kite eggplant tea airplane earthworm mouse star rocket television violin nut tunnel library yard door ruler rose envelope eagle eagle eye')
add_words('run walk jump eat drink write read speak sleep swim sing dance draw learn teach listen think build cook drive ride open close make take give bring carry throw catch watch play grow find help smile laugh cry study work buy sell sit stand fly', 'verb')
add_words('beautiful quickly carefully friendly brave happy', 'adjective')

INITIALS = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ']
JUNGSEONG = ['ㅏ','ㅐ','ㅑ','ㅒ','ㅓ','ㅔ','ㅕ','ㅖ','ㅗ','ㅘ','ㅙ','ㅚ','ㅛ','ㅜ','ㅝ','ㅞ','ㅟ','ㅠ','ㅡ','ㅢ','ㅣ']
JONGSEONG = ['', 'ㄱ','ㄲ','ㄳ','ㄴ','ㄵ','ㄶ','ㄷ','ㄹ','ㄺ','ㄻ','ㄼ','ㄽ','ㄾ','ㄿ','ㅀ','ㅁ','ㅂ','ㅄ','ㅅ','ㅆ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ']
HANGUL_BASE = 0xAC00

ROOMS = {}
ROOM_LOCK = threading.RLock()


def get_initials(text):
    result = []
    for ch in text:
        code = ord(ch) - HANGUL_BASE
        if 0 <= code < 11172:
            result.append(INITIALS[code // 588])
        elif ch.isalpha():
            result.append(ch.lower())
    return ''.join(result)


def decompose_hangul(ch):
    code = ord(ch) - HANGUL_BASE
    if not 0 <= code < 11172:
        return None
    return code // 588, (code % 588) // 28, code % 28


def compose_hangul(cho, jung, jong):
    return chr(HANGUL_BASE + cho * 588 + jung * 28 + jong)


def dueum_forms(ch):
    parts = decompose_hangul(ch)
    if not parts:
        return {ch}
    cho, jung, jong = parts
    forms = {ch}
    # In standard initial-sound rules, ㄴ/ㄹ can change depending on the following vowel.
    if INITIALS[cho] in ('ㄴ', 'ㄹ'):
        i_vowels = {2, 6, 7, 12, 17, 20}  # ㅑ/ㅕ/ㅖ/ㅛ/ㅠ/ㅣ
        if jung in i_vowels:
            forms.add(compose_hangul(INITIALS.index('ㅇ'), jung, jong))
        if INITIALS[cho] == 'ㄹ':
            replacement = 'ㅇ' if jung in i_vowels else 'ㄴ'
            forms.add(compose_hangul(INITIALS.index(replacement), jung, jong))
    return forms


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    user = db.session.get(User, uid)
    if not user or user.is_banned:
        return None
    return user


def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            session.clear()
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapped


def room_summary(room):
    return {
        'id': room['id'], 'name': room['name'], 'kind': room['kind'],
        'players': len(room['players']), 'max_players': room['max_players'],
        'started': room['started'], 'host': room['host_nickname'],
        'part': room['part'], 'dueum': room['dueum'], 'chosung': room['chosung']
    }


def room_snapshots():
    with ROOM_LOCK:
        return [room_summary(r) for r in ROOMS.values() if not r['finished']]


def broadcast_rooms():
    socketio.emit('rooms_update', room_snapshots())


def payload_for_room(room):
    players = []
    for p in room['players']:
        players.append({'id': p['user_id'], 'nickname': p['nickname'], 'is_host': p['user_id'] == room['host_id'],
                        'is_out': p.get('out', False), 'points': p.get('earned', 0)})
    current = None
    if room['started'] and room['players']:
        active = [p for p in room['players'] if not p.get('out')]
        if active:
            current = active[room['turn_index'] % len(active)]['user_id']
    return {
        'id': room['id'], 'name': room['name'], 'kind': room['kind'], 'part': room['part'],
        'dueum': room['dueum'], 'chosung': room['chosung'], 'started': room['started'],
        'finished': room['finished'], 'host_id': room['host_id'], 'players': players,
        'current_user_id': current, 'last_word': room['last_word'], 'history': room['history'][-30:],
        'message': room.get('message', ''), 'winner': room.get('winner')
    }


def send_room_state(room):
    socketio.emit('room_state', payload_for_room(room), to='game_' + room['id'])


def finish_if_one_left(room):
    """Finish a running match if at most one active player remains."""
    if not room['started'] or room['finished']:
        return False
    active = [p for p in room['players'] if not p.get('out')]
    if len(active) > 1:
        return False
    room['finished'] = True
    if active:
        winner_player = active[0]
        winner = db.session.get(User, winner_player['user_id'])
        if winner:
            winner.points += 50
            winner.wins += 1
        room['winner'] = winner_player['nickname']
        room['message'] = f"{winner_player['nickname']} 승리! 승리 보너스 +50점"
    else:
        room['winner'] = None
        room['message'] = '모두 기권했어.'
    db.session.commit()
    return True


def get_bank(kind):
    return KOREAN_BANK if kind == 'ko' else ENGLISH_BANK


def word_pos_allowed(word, room):
    part = room['part']
    if part == 'all':
        return True
    bank = get_bank(room['kind'])
    return bank.get(word, '') == part


def valid_word(word, room, user_id):
    word = re.sub(r'\s+', '', word).strip()
    if not word:
        return False, '단어를 입력해 줘.', word
    if len(word) > 40:
        return False, '단어가 너무 길어.', word
    if room['kind'] == 'hunmin':
        if not re.fullmatch(r'[가-힣]+', word):
            return False, '훈민정음은 한글 단어만 입력할 수 있어.', word
        if get_initials(word) != room['chosung'].replace(' ', ''):
            return False, f"초성이 맞지 않아. 초성은 {room['chosung']} 이야.", word
        if word in room['used_words']:
            return False, '이미 나온 단어야.', word
        return True, '', word
    if room['kind'] == 'ko':
        word = word
        if not re.fullmatch(r'[가-힣]+', word):
            return False, '한국어 단어만 입력할 수 있어.', word
    else:
        word = word.lower()
        if not re.fullmatch(r'[a-z]+', word):
            return False, '영어 단어는 알파벳만 입력할 수 있어.', word
    bank = get_bank(room['kind'])
    if word not in bank:
        return False, '기본 사전에 없는 단어야. 현재 사전은 확장할 수 있어!', word
    if not word_pos_allowed(word, room):
        label = {'noun': '명사', 'verb': '동사', 'adjective': '형용사'}.get(room['part'], '선택한 품사')
        return False, f'{label}만 입력할 수 있는 방이야.', word
    if word in room['used_words']:
        return False, '이미 나온 단어야.', word
    if room['last_word']:
        if room['kind'] == 'en':
            if word[0] != room['last_word'][-1]:
                return False, f"'{room['last_word'][-1]}'(으)로 시작해야 해.", word
        else:
            end_char = room['last_word'][-1]
            accepted = {end_char}
            if room['dueum']:
                accepted = dueum_forms(end_char)
            if word[0] not in accepted:
                return False, f"'{end_char}'(으)로 시작해야 해.", word
    return True, '', word


with app.app_context():
    db.create_all()
    admin = User.query.filter_by(nickname=ADMIN_NICKNAME).first()
    if not admin:
        admin = User(username='admin', nickname=ADMIN_NICKNAME,
                     password_hash=(generate_password_hash(ADMIN_PASSWORD) if ADMIN_PASSWORD else DEFAULT_ADMIN_PASSWORD_HASH), is_admin=True)
        db.session.add(admin)
        db.session.commit()
    elif not admin.is_admin:
        admin.is_admin = True
        db.session.commit()


@app.route('/')
@login_required
def index():
    user = current_user()
    top_users = User.query.filter_by(is_banned=False).order_by(User.points.desc(), User.wins.desc()).limit(10).all()
    return render_template('index.html', user=user, top_users=top_users)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user():
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        nickname = request.form.get('nickname', '').strip()
        password = request.form.get('password', '')
        if not re.fullmatch(r'[A-Za-z0-9_]{3,32}', username):
            flash('아이디는 영문, 숫자, 밑줄로 3~32자여야 해.', 'error')
        elif not re.fullmatch(r'[^\s]{2,24}', nickname):
            flash('닉네임은 공백 없이 2~24자로 입력해 줘.', 'error')
        elif len(password) < 4:
            flash('비밀번호는 4자 이상으로 설정해 줘.', 'error')
        elif User.query.filter_by(username=username).first():
            flash('이미 사용 중인 아이디야.', 'error')
        elif User.query.filter_by(nickname=nickname).first():
            flash('이미 사용 중인 닉네임이야.', 'error')
        else:
            user = User(username=username, nickname=nickname, password_hash=generate_password_hash(password))
            db.session.add(user)
            db.session.commit()
            session.clear()
            session['user_id'] = user.id
            flash('가입했어! 바로 게임을 시작해 봐.', 'success')
            return redirect(url_for('index'))
    return render_template('auth.html', mode='register')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user():
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        # Admin may sign in using the admin nickname instead of the internal username.
        if not user and username == ADMIN_NICKNAME:
            user = User.query.filter_by(nickname=ADMIN_NICKNAME).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash('아이디 또는 비밀번호를 확인해 줘.', 'error')
        elif user.is_banned:
            flash('이 계정은 이용이 제한되어 있어. 사유: ' + (user.ban_reason or '관리자에 의해 제한됨'), 'error')
        else:
            session.clear()
            session['user_id'] = user.id
            return redirect(url_for('index'))
    return render_template('auth.html', mode='login')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/leaderboard')
@login_required
def leaderboard():
    users = User.query.filter_by(is_banned=False).order_by(User.points.desc(), User.wins.desc()).limit(100).all()
    return render_template('leaderboard.html', user=current_user(), users=users)


@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin_panel():
    user = current_user()
    if not user.is_admin:
        return render_template('forbidden.html', user=user), 403
    if request.method == 'POST':
        action = request.form.get('action', '')
        target_id = request.form.get('user_id', type=int)
        target = db.session.get(User, target_id) if target_id else None
        if not target:
            flash('대상을 찾을 수 없어.', 'error')
        elif target.is_admin:
            flash('관리자 계정은 여기서 제재할 수 없어.', 'error')
        elif action == 'ban':
            target.is_banned = True
            target.ban_reason = request.form.get('reason', '').strip()[:240] or '관리자 제재'
            db.session.commit()
            with ROOM_LOCK:
                for room in list(ROOMS.values()):
                    removed = [p for p in room['players'] if p['user_id'] == target.id]
                    for player in removed:
                        try:
                            socketio.emit('notice', {'message': '관리자에 의해 이용이 제한됐어.'}, to=player['sid'])
                            socketio.server.disconnect(player['sid'], namespace='/')
                        except Exception:
                            pass
                    if removed:
                        if room['started'] and not room['finished']:
                            for player in removed:
                                player['out'] = True
                            finish_if_one_left(room)
                        else:
                            room['players'] = [p for p in room['players'] if p['user_id'] != target.id]
                            if room['host_id'] == target.id and room['players']:
                                room['host_id'] = room['players'][0]['user_id']
                                room['host_nickname'] = room['players'][0]['nickname']
                            if not room['players']:
                                ROOMS.pop(room['id'], None)
                        if room['id'] in ROOMS:
                            room['turn_index'] = 0
                            send_room_state(room)
            broadcast_rooms()
            flash(f'{target.nickname} 계정을 밴했어.', 'success')
        elif action == 'unban':
            target.is_banned = False
            target.ban_reason = ''
            db.session.commit()
            flash(f'{target.nickname} 계정의 밴을 해제했어.', 'success')
        elif action == 'points':
            delta = request.form.get('delta', type=int)
            if delta is None:
                flash('변경할 점수를 숫자로 입력해 줘.', 'error')
            else:
                target.points = max(0, target.points + max(-100000, min(100000, delta)))
                db.session.commit()
                flash(f'{target.nickname}의 점수를 변경했어.', 'success')
        return redirect(url_for('admin_panel'))
    users = User.query.order_by(User.created_at.desc()).limit(200).all()
    return render_template('admin.html', user=user, users=users)


@socketio.on('connect')
def on_connect(auth=None):
    user = current_user()
    if not user:
        return False
    emit('rooms_update', room_snapshots())
    emit('me', user.public())


@socketio.on('get_rooms')
def on_get_rooms():
    emit('rooms_update', room_snapshots())


@socketio.on('create_room')
def on_create_room(data):
    user = current_user()
    if not user:
        emit('notice', {'message': '로그인이 필요해.'})
        return
    data = data or {}
    name = str(data.get('name', '')).strip()[:28] or f'{user.nickname}의 방'
    kind = data.get('kind', 'ko')
    if kind not in ('ko', 'en', 'hunmin'):
        kind = 'ko'
    part = data.get('part', 'all')
    if part not in ('all', 'noun', 'verb', 'adjective'):
        part = 'all'
    if kind == 'hunmin':
        part = 'all'
    dueum = bool(data.get('dueum', True))
    chosung = re.sub(r'\s+', '', str(data.get('chosung', 'ㅅㄴㄲ')))
    if not re.fullmatch(r'[ㄱ-ㅎ]{1,12}', chosung):
        chosung = 'ㅅㄴㄲ'
    with ROOM_LOCK:
        # Finished rooms do not count against the active-room limit.
        for old_id, old_room in list(ROOMS.items()):
            if old_room['finished'] and time.time() - old_room.get('created', 0) > 300:
                ROOMS.pop(old_id, None)
        if sum(1 for r in ROOMS.values() if not r['finished']) >= 50:
            emit('notice', {'message': '현재 진행 중인 방이 많아. 잠시 뒤 다시 시도해 줘.'})
            return
        rid = uuid.uuid4().hex[:8]
        room = {'id': rid, 'name': name, 'kind': kind, 'part': part, 'dueum': dueum,
                'chosung': chosung, 'max_players': 8, 'host_id': user.id,
                'host_nickname': user.nickname, 'players': [], 'started': False,
                'finished': False, 'turn_index': 0, 'last_word': '', 'used_words': set(),
                'history': [], 'created': time.time(), 'winner': None, 'message': '방장이 게임을 시작할 수 있어.'}
        ROOMS[rid] = room
    on_join_room({'room_id': rid})
    broadcast_rooms()


@socketio.on('join_room')
def on_join_room(data):
    user = current_user()
    if not user:
        emit('notice', {'message': '로그인이 필요해.'})
        return
    rid = str((data or {}).get('room_id', ''))
    with ROOM_LOCK:
        room = ROOMS.get(rid)
        if not room or room['finished']:
            emit('notice', {'message': '방이 없어졌어.'})
            return
        if room['started']:
            emit('notice', {'message': '이미 게임이 시작된 방이야.'})
            return
        if len(room['players']) >= room['max_players']:
            emit('notice', {'message': '방이 꽉 찼어.'})
            return
        existing = next((p for p in room['players'] if p['user_id'] == user.id), None)
        if existing:
            existing['sid'] = request.sid
        else:
            room['players'].append({'user_id': user.id, 'nickname': user.nickname, 'sid': request.sid,
                                    'out': False, 'earned': 0})
        join_room('game_' + rid)
        session['active_room'] = rid
        emit('joined_room', {'room_id': rid, 'user_id': user.id})
        send_room_state(room)
    broadcast_rooms()


@socketio.on('start_game')
def on_start_game(data):
    user = current_user()
    rid = str((data or {}).get('room_id', ''))
    with ROOM_LOCK:
        room = ROOMS.get(rid)
        if not user or not room:
            return
        if room['host_id'] != user.id:
            emit('notice', {'message': '방장만 게임을 시작할 수 있어.'})
            return
        if len(room['players']) < 2:
            emit('notice', {'message': '최소 2명이 모여야 시작할 수 있어.'})
            return
        room['started'] = True
        room['finished'] = False
        room['turn_index'] = random.randrange(len(room['players']))
        room['message'] = '게임 시작! 차례에 맞춰 단어를 입력해 줘.'
        room['last_word'] = ''
        room['used_words'].clear()
        room['history'].clear()
        for p in room['players']:
            p['out'] = False
            p['earned'] = 0
            u = db.session.get(User, p['user_id'])
            if u:
                u.games += 1
        db.session.commit()
        send_room_state(room)
    broadcast_rooms()


@socketio.on('submit_word')
def on_submit_word(data):
    user = current_user()
    data = data or {}
    rid = str(data.get('room_id', ''))
    raw_word = str(data.get('word', '')).strip()
    with ROOM_LOCK:
        room = ROOMS.get(rid)
        if not user or not room or not room['started'] or room['finished']:
            emit('word_result', {'ok': False, 'message': '진행 중인 게임이 없어.'})
            return
        active_players = [p for p in room['players'] if not p.get('out')]
        if not active_players:
            return
        current = active_players[room['turn_index'] % len(active_players)]
        if current['user_id'] != user.id:
            emit('word_result', {'ok': False, 'message': '아직 네 차례가 아니야.'})
            return
        ok, message, word = valid_word(raw_word, room, user.id)
        if not ok:
            emit('word_result', {'ok': False, 'message': message})
            return
        room['last_word'] = word
        room['used_words'].add(word)
        room['history'].append({'word': word, 'nickname': user.nickname, 'user_id': user.id, 'at': datetime.utcnow().strftime('%H:%M:%S')})
        player = next((p for p in room['players'] if p['user_id'] == user.id), None)
        if player:
            player['earned'] += 10
        user.points += 10
        db.session.commit()
        emit('word_result', {'ok': True, 'message': '+10점!'}, to=request.sid)
        if len(active_players) == 1:
            room['finished'] = True
        else:
            # Find next non-eliminated participant.
            current_position = active_players.index(current)
            room['turn_index'] = (current_position + 1) % len(active_players)
        room['message'] = f'{user.nickname} 입력: {word}'
        send_room_state(room)
    broadcast_rooms()


@socketio.on('surrender')
def on_surrender(data):
    user = current_user()
    rid = str((data or {}).get('room_id', ''))
    with ROOM_LOCK:
        room = ROOMS.get(rid)
        if not user or not room or not room['started'] or room['finished']:
            return
        player = next((p for p in room['players'] if p['user_id'] == user.id and not p.get('out')), None)
        if not player:
            return
        player['out'] = True
        if not finish_if_one_left(room):
            room['turn_index'] = 0
            room['message'] = f'{user.nickname} 님이 기권했어.'
        send_room_state(room)
    broadcast_rooms()


@socketio.on('leave_room')
def on_leave_room(data):
    rid = str((data or {}).get('room_id', ''))
    user = current_user()
    with ROOM_LOCK:
        room = ROOMS.get(rid)
        if not room:
            return
        leaving = next((p for p in room['players'] if user and p['user_id'] == user.id), None)
        leave_room('game_' + rid)
        if leaving and room['started'] and not room['finished']:
            leaving['out'] = True
            if not finish_if_one_left(room):
                room['message'] = f"{leaving['nickname']} 님이 방을 나갔어."
                room['turn_index'] = 0
            send_room_state(room)
        else:
            room['players'] = [p for p in room['players'] if not (user and p['user_id'] == user.id)]
            if not room['players']:
                ROOMS.pop(rid, None)
            else:
                if user and room['host_id'] == user.id:
                    room['host_id'] = room['players'][0]['user_id']
                    room['host_nickname'] = room['players'][0]['nickname']
                room['turn_index'] = 0
                send_room_state(room)
    session.pop('active_room', None)
    broadcast_rooms()


@socketio.on('disconnect')
def on_disconnect():
    user = current_user()
    with ROOM_LOCK:
        for rid, room in list(ROOMS.items()):
            matched = [p for p in room['players'] if p['sid'] == request.sid or (user and p['user_id'] == user.id and not room['started'])]
            if not matched:
                continue
            if room['started'] and not room['finished']:
                for player in matched:
                    player['out'] = True
                if not finish_if_one_left(room):
                    room['message'] = '참가자가 연결을 종료했어.'
                    room['turn_index'] = 0
                send_room_state(room)
            else:
                room['players'] = [p for p in room['players'] if p not in matched]
                if not room['players']:
                    ROOMS.pop(rid, None)
                else:
                    if room['host_id'] in [p['user_id'] for p in matched]:
                        room['host_id'] = room['players'][0]['user_id']
                        room['host_nickname'] = room['players'][0]['nickname']
                    room['turn_index'] = 0
                    send_room_state(room)
    broadcast_rooms()


@app.get('/api/me')
@login_required
def api_me():
    return jsonify(current_user().public())


@app.get('/healthz')
def healthz():
    return {'ok': True}


if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=int(os.getenv('PORT', 5000)), debug=True)
